ALPHA HUSKY / TACTICAL OPS / EXISTING REUSABLE ASSETS
KACPER HANDOFF — 2026-10-23

Repository: https://github.com/Skrwl1909/alpha-husky-webapp
Pinned source base commit: 458d405e8589663276f1fb0ec946f6db5ff64758

ORIGINAL REPO FILES (37):
- 9 canonical action icons (Alpha / CNC / Shadow)
- 9 core and discipline emblems
- 16 Command Deck frame PNG assets
- command_room.webp
- mission_hologram.webp
- frames_manifest.json

All original repository-relative paths are kept unchanged.
This is the REUSE package only. The 13 NEW Signal Atlas V1 masters
(ENV-01, ENV-02, CORE-01, 6 new sector crests, 3 frames and trim)
are not included.
Signal Atlas / Sector Focus are code-driven UI screens, not standalone
art images.

See ASSET_INVENTORY.json for full file names, sizes and SHA-256.
GAME FIRST. HISTORY RECORDED HONESTLY.
